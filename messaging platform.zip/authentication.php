<?php  
    include('connection.php');  
    
    
    $username = $_POST['user'];  
    $password = $_POST['pass'];

        //to prevent from mysqli injection  
        $username = stripcslashes($username);  
        $password = stripcslashes($password);  
        $username = mysqli_real_escape_string($con, $username);  
        $password = mysqli_real_escape_string($con, $password);  
      
        $sql = "select * from login where username = '$username' and password = '$password'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          
        if($count == 1){  
            echo "<h1><center> Login successful </center></h1>";
            echo "<h1><center> Welcome $username </center></h1>";
            
            
            echo '<div id="redirect">
                    <p>Please enter the name you want to be displayed!</p>
                    <form action="account.php" method="post">
                      <label for="name">Name &mdash;</label>
                      <input type="text" name="name" id="name" />
                      <input type="submit" name="enter" id="enter" value="Enter the World" />
                    </form>
                  </div>';
        }  
        else{  
            echo "<h1><center> Login failed. Invalid username or password.<center></h1>";
            echo $username;
        }     
    
?>  
