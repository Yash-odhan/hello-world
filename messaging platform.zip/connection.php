<?php      
    $host = "localhost";  
    $user = "id17835559_root";  
    $password = "CB2NUTchR+eBVg?<";  
    $db_name = "id17835559_logins";  
      
    $con = mysqli_connect($host, $user, $password, $db_name);  
    if(mysqli_connect_errno()) {  
        die("Failed to connect with MySQL: ". mysqli_connect_error());  
    }
    echo "Connection Successful";
?>  
